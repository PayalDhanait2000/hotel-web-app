import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { response } from 'express';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export  class CartComponent implements OnInit {

  cartItem:any[0];
  constructor(private apiServices:ApiService){

  }
  ngOnInit(){
    this.getCartItems();
  }
  getCartItems(){
    this.apiServices.getCartItems().subscribe(
      (response)=>{
        this.cartItem = response;
      },
      (error)=>{
        console.log(error);
      }

    );
  }
}
