import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { response } from 'express';
@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {

  totalAmount:number =0;
  constructor(private apiService:ApiService){}

  ngOnInit(){
    this.generateBill();
  }
  generateBill()
  {
    this.apiService.generateBill().subscribe(
      (response)=>{
        this.totalAmount = response.totalAmount;
      },
      (error)=>{
        console.log(error);
      }
    );
  }

}
